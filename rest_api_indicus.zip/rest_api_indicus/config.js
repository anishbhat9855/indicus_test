module.exports = {
    MONGO_URI: 'mongodb://cand:DjO9keRUpfhDtd0S@cluster0-shard-00-00.1ogkw.mongodb.net:27017,cluster0-shard-00-01.1ogkw.mongodb.net:27017,cluster0-shard-00-02.1ogkw.mongodb.net:27017/indicus_db?ssl=true&replicaSet=atlas-czl2q9-shard-0&authSource=admin&retryWrites=true&w=majority'
}